@echo off
dism >nul 2>&1 || (echo ^<Run Script In Administrator^> && pause>nul && cls&exit)
title WiFi Tool

echo.
echo ============================================
echo             WiFi Service Tool
echo ============================================
echo.

choice /C ED /N /M "Do you want to [E] Enable or [D] Disable WiFi? (E/D): "

if %errorlevel%==1 goto ENABLE
if %errorlevel%==2 goto DISABLE

:ENABLE
color 0A
echo.
echo [ENABLING] WiFi Services...
echo.
sc config WlanSvc start=auto >nul 2>&1
sc config WwanSvc start=demand >nul 2>&1
sc config NativeWifiP start=auto >nul 2>&1
sc config vwififlt start=system >nul 2>&1
sc config ndisuio start=demand >nul 2>&1
sc config icssvc start=demand >nul 2>&1
sc config Wcmsvc start=auto >nul 2>&1
sc config WFDSConMgrSvc start=demand >nul 2>&1
sc config NetSetupSvc start=demand >nul 2>&1
sc config tdx start=system >nul 2>&1
sc config netman start=demand >nul 2>&1
sc config netprofm start=demand >nul 2>&1
sc config NlaSvc start=auto >nul 2>&1
sc config nsi start=auto >nul 2>&1
echo.
echo  WiFi has been ENABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:DISABLE
color 0C
echo.
echo [DISABLING] WiFi Services...
echo.
sc config WlanSvc start=disabled error=ignore >nul 2>&1
sc config WwanSvc start=disabled error=ignore >nul 2>&1
sc config NativeWifiP start=disabled error=ignore >nul 2>&1
sc config vwififlt start=disabled error=ignore >nul 2>&1
sc config icssvc start=disabled error=ignore >nul 2>&1
sc config Wcmsvc start=disabled error=ignore >nul 2>&1
sc config WFDSConMgrSvc start=disabled error=ignore >nul 2>&1
sc config NetSetupSvc start=disabled error=ignore >nul 2>&1
sc config tdx start=disabled error=ignore >nul 2>&1
echo.
echo  WiFi has been DISABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:END
color 0F
exit