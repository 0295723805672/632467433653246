@echo off
dism >nul 2>&1 || (echo ^<Run Script In Administrator^> && pause>nul && cls&exit)
title Bluetooth Tool

echo.
echo ============================================
echo           Bluetooth Service Tool
echo ============================================
echo.

choice /C ED /N /M "Do you want to [E] Enable or [D] Disable Bluetooth? (E/D): "

if %errorlevel%==1 goto ENABLE
if %errorlevel%==2 goto DISABLE

:ENABLE
color 0A
echo.
echo [ENABLING] Bluetooth Services...
echo.
sc config bthserv start=auto >nul 2>&1
sc config BluetoothUserService start=auto >nul 2>&1
sc config BTAGService start=auto >nul 2>&1
sc config BthAvctpSvc start=auto >nul 2>&1
sc config BthEnum start=auto >nul 2>&1
sc config HidBth start=auto >nul 2>&1
sc config Microsoft_Bluetooth_AvrcpTransport start=auto >nul 2>&1
sc config BthHFEnum start=auto >nul 2>&1
sc config BthLEEnum start=auto >nul 2>&1
sc config BthMini start=auto >nul 2>&1
sc config BTHMODEM start=auto >nul 2>&1
sc config BTHPORT start=auto >nul 2>&1
sc config BTHUSB start=auto >nul 2>&1
sc config RFCOMM start=auto >nul 2>&1
echo.
echo  Bluetooth has been ENABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:DISABLE
color 0C
echo.
echo [DISABLING] Bluetooth Services...
echo.
sc config bthserv start=disabled >nul 2>&1
sc config BluetoothUserService start=disabled >nul 2>&1
sc config BTAGService start=disabled >nul 2>&1
sc config BthAvctpSvc start=disabled >nul 2>&1
sc config BthEnum start=disabled >nul 2>&1
sc config HidBth start=disabled >nul 2>&1
sc config Microsoft_Bluetooth_AvrcpTransport start=disabled >nul 2>&1
sc config BthHFEnum start=disabled >nul 2>&1
sc config BthLEEnum start=disabled >nul 2>&1
sc config BthMini start=disabled >nul 2>&1
sc config BTHMODEM start=disabled >nul 2>&1
sc config BTHPORT start=disabled >nul 2>&1
sc config BTHUSB start=disabled >nul 2>&1
sc config RFCOMM start=disabled >nul 2>&1
echo.
echo  Bluetooth has been DISABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:END
color 0F
exit