@echo off
dism >nul 2>&1 || (echo ^<Run Script In Administrator^> && pause>nul && cls&exit)
title Xbox Service Tool

echo.
echo ============================================
echo            Xbox Service Tool
echo ============================================
echo.

choice /C ED /N /M "Do you want to [E] Enable or [D] Disable Xbox Services? (E/D): "

if %errorlevel%==1 goto ENABLE
if %errorlevel%==2 goto DISABLE

:ENABLE
color 0A
echo.
echo [ENABLING] Xbox Services...
echo.
sc config BcastDVRUserService start=auto >nul 2>&1
sc config xboxgip start=auto >nul 2>&1
sc config xbgm start=auto >nul 2>&1
sc config XboxNetApiSvc start=auto >nul 2>&1
sc config XblGameSave start=auto >nul 2>&1
sc config XboxGipSvc start=auto >nul 2>&1
sc config xblauthmanager start=auto >nul 2>&1
echo.
echo  Xbox Services have been ENABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:DISABLE
color 0C
echo.
echo [DISABLING] Xbox Services...
echo.
sc config BcastDVRUserService start=disabled >nul 2>&1
sc config xboxgip start=disabled >nul 2>&1
sc config xbgm start=disabled >nul 2>&1
sc config XboxNetApiSvc start=disabled >nul 2>&1
sc config XblGameSave start=disabled >nul 2>&1
sc config XboxGipSvc start=disabled >nul 2>&1
sc config xblauthmanager start=disabled >nul 2>&1
echo.
echo  Xbox Services have been DISABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:END
color 0F
exit