@echo off
color 0F
title Network Autotuning Tool

echo.
echo ============================================
echo     Network Autotuning Level Tool
echo ============================================
echo.
echo  What does Autotuning affect?
echo.
echo  [DISABLED] - Slows down download speed but
echo               improves latency. Best for gaming,
echo               low-ping tasks and reducing lag.
echo.
echo  [NORMAL]   - Speeds up download speed but
echo               increases latency. Best for
echo               browsing, streaming and large downloads.
echo.
echo ============================================
echo.

choice /C DN /N /M "Do you want to set Autotuning to [D] Disabled or [N] Normal? (D/N): "

if %errorlevel%==1 goto DISABLE
if %errorlevel%==2 goto NORMAL

:DISABLE
color 0C
echo.
echo [DISABLING] Network Autotuning...
echo.
netsh int tcp set global autotuninglevel=disabled
echo.
echo  Autotuning has been set to DISABLED.
echo  Download speed may be slower but latency
echo  and ping will be improved.
echo.
echo  A restart is recommended for full effect.
echo.
pause
goto END

:NORMAL
color 0A
echo.
echo [ENABLING] Network Autotuning (Normal)...
echo.
netsh int tcp set global autotuninglevel=normal
echo.
echo  Autotuning has been set to NORMAL.
echo  Download speed will be faster but latency
echo  and ping may increase slightly.
echo.
echo  A restart is recommended for full effect.
echo.
pause
goto END

:END
color 0F
exit