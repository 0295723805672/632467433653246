@echo off
color 0F
title VBS - Virtualization Based Security Tool

choice /C ED /N /M "Do you want to [E] Enable or [D] Disable VBS? (E/D): "

if %errorlevel%==1 goto ENABLE
if %errorlevel%==2 goto DISABLE

:ENABLE
color 0A
echo.
echo [ENABLING] Virtualization Based Security...
echo.
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\CredentialGuard" /v "Enabled" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d "1" /f
echo.
echo  VBS has been ENABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:DISABLE
color 0C
echo.
echo [DISABLING] Virtualization Based Security...
echo.
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\CredentialGuard" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d "0" /f
echo.
echo  VBS has been DISABLED successfully.
echo  You MUST restart Windows for it to take effect.
echo.
pause
goto END

:END
color 0F
exit