sc.exe sidtype wuauserv unrestricted
Stop-Service wuauserv -Force
Start-Service wuauserv