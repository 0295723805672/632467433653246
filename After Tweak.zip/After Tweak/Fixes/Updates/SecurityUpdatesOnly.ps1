# ============================================================
#  Security Updates Only - Windows Update Configuration
#  Right-click > Run with PowerShell  (auto-elevates)
# ============================================================

# Auto-elevate to Administrator
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator")) {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

Clear-Host
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "   Configuring Windows Update: Security Updates Only"          -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""

# ------------------------------------------------------------------
# 1. Set Windows Update policy via registry
# ------------------------------------------------------------------
Write-Host "[1/5] Setting Windows Update policy..." -ForegroundColor Yellow

$auPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
If (-not (Test-Path $auPath)) { New-Item -Path $auPath -Force | Out-Null }

Set-ItemProperty -Path $auPath -Name "NoAutoUpdate"            -Value 0 -Type DWord
Set-ItemProperty -Path $auPath -Name "AUOptions"               -Value 3 -Type DWord  # 3 = Download, prompt to install
Set-ItemProperty -Path $auPath -Name "AutoInstallMinorUpdates" -Value 0 -Type DWord

Write-Host "   Done." -ForegroundColor Green

# ------------------------------------------------------------------
# 2. Block driver and feature updates
# ------------------------------------------------------------------
Write-Host "[2/5] Blocking non-security update categories..." -ForegroundColor Yellow

$wuPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
If (-not (Test-Path $wuPath)) { New-Item -Path $wuPath -Force | Out-Null }

Set-ItemProperty -Path $wuPath -Name "DisableDualScan"                 -Value 1 -Type DWord
Set-ItemProperty -Path $wuPath -Name "ExcludeWUDriversInQualityUpdate" -Value 1 -Type DWord

Write-Host "   Done." -ForegroundColor Green

# ------------------------------------------------------------------
# 3. Install PSWindowsUpdate module if missing
# ------------------------------------------------------------------
Write-Host "[3/5] Checking PSWindowsUpdate module..." -ForegroundColor Yellow

if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) {
    Write-Host "   Module not found. Installing from PSGallery..." -ForegroundColor Yellow
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
    Install-Module -Name PSWindowsUpdate -Force -Scope AllUsers
    Write-Host "   Installed." -ForegroundColor Green
} else {
    Write-Host "   Already installed." -ForegroundColor Green
}

Import-Module PSWindowsUpdate

# ------------------------------------------------------------------
# 4. Scan for available security updates
# ------------------------------------------------------------------
Write-Host "[4/5] Scanning for security updates..." -ForegroundColor Yellow

$updates = Get-WUList -Category "Security Updates" -MicrosoftUpdate

if ($updates.Count -eq 0) {
    Write-Host "   No pending security updates found." -ForegroundColor Green
} else {
    Write-Host "   Found $($updates.Count) security update(s):" -ForegroundColor Yellow
    $updates | Select-Object Title, Size, MsrcSeverity | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 5. Install security updates
# ------------------------------------------------------------------
Write-Host "[5/5] Installing security updates..." -ForegroundColor Yellow

if ($updates.Count -gt 0) {
    Install-WindowsUpdate -Category "Security Updates" -MicrosoftUpdate -AcceptAll -AutoReboot
    Write-Host "   Installation complete." -ForegroundColor Green
} else {
    Write-Host "   Nothing to install." -ForegroundColor Green
}

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "   All done! Security-only update policy is now active."        -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""
Read-Host "  Press Enter to close"
