@echo off

ipconfig /flushdns

timeout /t 5

netsh int ipv4 reset

timeout /t 5

netsh int ipv6 reset

timeout /t 5

netsh winsock reset


